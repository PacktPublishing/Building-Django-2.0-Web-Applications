# Mail Ape 🦍

## Deployment Environment

To use the deployment scripts you need a couple environment variables:

 - `export AWS_ACCESS_KEY=''`
 - `export AWS_SECRET_KEY=''`
 - `export EMAIL_HOST=''`
 - `export EMAIL_HOST_PASSWORD=''`
 
 