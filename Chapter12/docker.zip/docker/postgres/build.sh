#!/usr/bin/env bash

docker build . -t tomaratyn/mailape_postgres