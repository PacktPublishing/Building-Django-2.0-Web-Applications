#!/usr/bin/env bash

curl -XPUT "$1/answerly?pretty"